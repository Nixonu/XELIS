#!/usr/bin/env bash

if [[ ! -z $CUSTOM_USER_CONFIG ]] ; then 
	while IFS= read -r line; do
		[[ -z $line ]] && continue
	        # Check if the line starts with 'nvtool ' and execute it using eval
        	if [[ ${line:0:7} = "nvtool " ]]; then
	        	eval "$line"
		fi
	done <<< "$CUSTOM_USER_CONFIG"
fi


[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1

conf="--wallet ${CUSTOM_TEMPLATE} --host ${CUSTOM_URL}"
[[ ! -z ${CUSTOM_PASS} ]] && conf+=" --worker ${CUSTOM_PASS} "
#conf+=" ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM_CONFIG_FILENAME

